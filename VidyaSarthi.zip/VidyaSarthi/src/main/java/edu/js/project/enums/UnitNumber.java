package edu.js.project.enums;

public enum UnitNumber {

    ONE,
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX

}
