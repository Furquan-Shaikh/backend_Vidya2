package edu.js.project.dto;

public record LogoutRequest(String token) {
}
