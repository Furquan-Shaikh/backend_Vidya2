package edu.js.project.dto;

import lombok.Data;

@Data
public class LoginRequest {

    String email;
    String password;
}
