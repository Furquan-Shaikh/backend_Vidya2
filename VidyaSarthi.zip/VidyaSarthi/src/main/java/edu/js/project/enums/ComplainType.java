package edu.js.project.enums;

public enum ComplainType {

    REQUEST,
    REPORT

}
