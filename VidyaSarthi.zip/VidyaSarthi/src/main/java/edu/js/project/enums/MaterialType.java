package edu.js.project.enums;

public enum MaterialType {

    NOTES,
    QUESTION_BANK,
    PYQ,
    ANNOUNCEMENT

}
