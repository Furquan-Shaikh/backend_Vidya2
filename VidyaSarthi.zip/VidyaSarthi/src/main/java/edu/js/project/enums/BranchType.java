package edu.js.project.enums;

public enum BranchType {

    CSE,
    CIVIL,
    EEE,
    IT

}
