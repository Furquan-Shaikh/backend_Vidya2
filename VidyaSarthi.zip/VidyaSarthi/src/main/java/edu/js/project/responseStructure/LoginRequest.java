package edu.js.project.responseStructure;

public record LoginRequest(String username, String password) {
}
