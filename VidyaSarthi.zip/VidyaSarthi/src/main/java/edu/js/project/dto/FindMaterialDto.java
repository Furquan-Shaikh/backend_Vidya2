package edu.js.project.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FindMaterialDto {

    private String subjectCode;
    private int unitNumber;
}
