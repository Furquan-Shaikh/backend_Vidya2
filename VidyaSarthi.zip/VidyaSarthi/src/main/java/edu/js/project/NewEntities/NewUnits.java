package edu.js.project.NewEntities;

public class NewUnits {
}
