package edu.js.project.NewEntities;

import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;


public class NewSemester {



}
