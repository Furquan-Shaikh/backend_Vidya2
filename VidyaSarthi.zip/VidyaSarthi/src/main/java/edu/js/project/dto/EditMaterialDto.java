package edu.js.project.dto;

import lombok.Data;

@Data
public class EditMaterialDto {

    private Long id;
    private String url;

}
