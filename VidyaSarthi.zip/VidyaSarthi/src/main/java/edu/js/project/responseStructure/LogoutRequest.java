package edu.js.project.responseStructure;

public record LogoutRequest(String token) {
}
