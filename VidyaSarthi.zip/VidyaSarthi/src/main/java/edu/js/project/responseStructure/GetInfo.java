package edu.js.project.responseStructure;

import lombok.Getter;

@Getter
public class GetInfo {

    String email;

}
