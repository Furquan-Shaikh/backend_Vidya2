package edu.js.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VidyaSarthiApplicationTests {

	@Test
	void contextLoads() {
	}

}
